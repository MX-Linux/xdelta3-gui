# *****************************************************************************
# * Copyright (C) 2023-2026 MX Authors
# *
# * Authors: Adrian <adrian@mxlinux.org>
# *          MX Linux <http://mxlinux.org>
# *
# * This file is part of xdelta3-gui.
# *
# * xdelta3-gui is free software: you can redistribute it and/or modify
# * it under the terms of the GNU General Public License as published by
# * the Free Software Foundation, either version 3 of the License, or
# * (at your option) any later version.
# *
# * xdelta3-gui is distributed in the hope that it will be useful,
# * but WITHOUT ANY WARRANTY; without even the implied warranty of
# * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# * GNU General Public License for more details.
# *
# * You should have received a copy of the GNU General Public License
# * along with xdelta3-gui.  If not, see <http://www.gnu.org/licenses/>.
# *****************************************************************************/

cmake_minimum_required(VERSION 3.16)

# Get version from debian/changelog
execute_process(
    COMMAND head -n 1 debian/changelog
    WORKING_DIRECTORY ${CMAKE_SOURCE_DIR}
    OUTPUT_VARIABLE FIRST_LINE
    OUTPUT_STRIP_TRAILING_WHITESPACE
)
string(REGEX REPLACE ".*\\(([^)]+)\\).*" "\\1" PROJECT_VERSION_FROM_CHANGELOG "${FIRST_LINE}")
if(NOT PROJECT_VERSION_FROM_CHANGELOG)
    message(FATAL_ERROR "Failed to parse version from debian/changelog")
endif()

project(xdelta3-gui
    VERSION ${PROJECT_VERSION_FROM_CHANGELOG}
    DESCRIPTION "xdelta3-gui - Graphical interface for xdelta3"
    LANGUAGES CXX
)

# Set C++ standard
set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

# Enable compile commands export for IDEs and tools
set(CMAKE_EXPORT_COMPILE_COMMANDS ON)

# Optimize for Ninja builds
if(CMAKE_GENERATOR STREQUAL "Ninja")
    # Enable colored output for Ninja
    if(CMAKE_CXX_COMPILER_ID STREQUAL "GNU")
        add_compile_options(-fdiagnostics-color=always)
    elseif(CMAKE_CXX_COMPILER_ID STREQUAL "Clang")
        add_compile_options(-fcolor-diagnostics)
    endif()
endif()

# Find Qt6 components
find_package(Qt6 REQUIRED COMPONENTS
    Core
    Gui
    Widgets
    LinguistTools
    DBus
)

# Enable automatic MOC, UIC, and RCC processing
set(CMAKE_AUTOMOC ON)
set(CMAKE_AUTOUIC ON)
set(CMAKE_AUTORCC ON)

# Define source files
set(SOURCES
    main.cpp
    mainwindow.cpp
    cmd.cpp
    droplineedit.cpp
)

set(HEADERS
    mainwindow.h
    cmd.h
    droplineedit.h
)

set(UI_FILES
    mainwindow.ui
)

# Get all translation files
file(GLOB TRANSLATION_FILES "translations/*.ts")
list(FILTER TRANSLATION_FILES EXCLUDE REGEX "/xdelta3-gui_en_US\\.ts$")

# Create the executable
add_executable(xdelta3-gui
    ${SOURCES}
    ${HEADERS}
    ${UI_FILES}
)

# Link Qt6 libraries
target_link_libraries(xdelta3-gui
    Qt6::Core
    Qt6::Gui
    Qt6::Widgets
    Qt6::DBus
)

# Include source directory for promoted widgets
target_include_directories(xdelta3-gui PRIVATE ${CMAKE_SOURCE_DIR})

# Set compiler flags
target_compile_options(xdelta3-gui PRIVATE
    -Wpedantic
    -Werror=return-type
    -Werror=switch
    -Werror=uninitialized
    -Werror
)

# Add compiler-specific flags
if(CMAKE_CXX_COMPILER_ID STREQUAL "Clang")
    target_compile_options(xdelta3-gui PRIVATE -Werror=return-stack-address)
else()
    target_compile_options(xdelta3-gui PRIVATE -Werror=return-local-addr)
endif()

# Set compile definitions
target_compile_definitions(xdelta3-gui PRIVATE
    QT_DEPRECATED_WARNINGS
    QT_DISABLE_DEPRECATED_BEFORE=0x060000
    VERSION="${PROJECT_VERSION}"
)

# Release-specific optimizations
if(CMAKE_BUILD_TYPE STREQUAL "Release")
    target_compile_definitions(xdelta3-gui PRIVATE NDEBUG)
    target_compile_options(xdelta3-gui PRIVATE -O3)

    # Add LTO - different flags for different compilers
    if(CMAKE_CXX_COMPILER_ID STREQUAL "Clang")
        target_compile_options(xdelta3-gui PRIVATE -flto=thin)
        target_link_options(xdelta3-gui PRIVATE -flto=thin)
    else()
        target_compile_options(xdelta3-gui PRIVATE -flto=auto)
        target_link_options(xdelta3-gui PRIVATE -flto=auto)
    endif()
endif()

# Handle translations
qt6_add_translations(xdelta3-gui
    TS_FILES ${TRANSLATION_FILES}
    LRELEASE_OPTIONS -compress -nounfinished -removeidentical -silent
    QM_FILES_OUTPUT_VARIABLE qm_files
)



# Set target properties
set_target_properties(xdelta3-gui PROPERTIES
    OUTPUT_NAME "xdelta3-gui"
    RUNTIME_OUTPUT_DIRECTORY ${CMAKE_BINARY_DIR}
)



install(TARGETS xdelta3-gui
    RUNTIME DESTINATION bin
)

# Shared data for desktop integration and translations
install(FILES xdelta3-gui.desktop DESTINATION share/applications)
install(FILES xdelta3-gui.png DESTINATION share/pixmaps)
install(FILES xdelta3-gui.svg DESTINATION share/icons/hicolor/scalable/apps)
install(FILES x-xdelta3.xml DESTINATION share/mime/packages)
install(FILES ${qm_files} DESTINATION share/xdelta3-gui/locale)
