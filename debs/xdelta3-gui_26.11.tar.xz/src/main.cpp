/**********************************************************************
 *
 **********************************************************************
 * Copyright (C) 2023-2026 MX Authors
 *
 * Authors: Adrian <adrian@mxlinux.org>
 *          MX Linux <http://mxlinux.org>
 *
 * This is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package. If not, see <http://www.gnu.org/licenses/>.
 **********************************************************************/
#include <QApplication>
#include <QCommandLineParser>
#include <QIcon>
#include <QLibraryInfo>
#include <QLocale>
#include <QMessageBox>
#include <QStandardPaths>
#include <QTranslator>

#include <memory>

#include "mainwindow.h"

#include <unistd.h>

#ifndef VERSION
    #define VERSION "?.?.?.?"
#endif

int main(int argc, char *argv[])
{
    const QByteArray option = argc == 2 ? QByteArray(argv[1]) : QByteArray();
    const bool informational = option == "-h" || option == "--help" || option == "--help-all"
                               || option == "-v" || option == "--version";
    std::unique_ptr<QCoreApplication> app;
    if (informational) {
        app = std::make_unique<QCoreApplication>(argc, argv);
    } else {
        if (qEnvironmentVariableIsEmpty("DISPLAY") && qEnvironmentVariableIsEmpty("WAYLAND_DISPLAY")
            && qEnvironmentVariableIsEmpty("QT_QPA_PLATFORM")) {
            qWarning("xdelta3-gui: no display available (DISPLAY and WAYLAND_DISPLAY are both unset); "
                    "a graphical session is required to run this program.");
            return EXIT_FAILURE;
        }

        // Set Qt platform to XCB (X11) if not already set and we're in X11 environment
        if (qEnvironmentVariableIsEmpty("QT_QPA_PLATFORM") && !qEnvironmentVariableIsEmpty("DISPLAY")
            && qEnvironmentVariableIsEmpty("WAYLAND_DISPLAY")) {
            qputenv("QT_QPA_PLATFORM", "xcb");
        }

        app = std::make_unique<QApplication>(argc, argv);
    }

    // Set these explicitly: the window icon, translation lookup, D-Bus launcher
    // entry, and QSettings all key off the application name. Relying on the
    // executable basename would silently break them if the binary is renamed.
    QApplication::setOrganizationName("MX Linux");
    QApplication::setApplicationName("xdelta3-gui");

    QApplication::setApplicationVersion(VERSION);

    // Install translators before anything user-visible is built: the --help
    // text and the missing-xdelta3 dialog below are translated too.
    QTranslator qtTran;
    if (qtTran.load(QLocale::system(), "qt", "_", QLibraryInfo::path(QLibraryInfo::TranslationsPath))) {
        QApplication::installTranslator(&qtTran);
    }

    QTranslator qtBaseTran;
    if (qtBaseTran.load("qtbase_" + QLocale::system().name(), QLibraryInfo::path(QLibraryInfo::TranslationsPath))) {
        QApplication::installTranslator(&qtBaseTran);
    }

    QTranslator appTran;
    const QString translationName = QApplication::applicationName() + "_" + QLocale::system().name();
    const QStringList searchPaths = {
        QCoreApplication::applicationDirPath() + "/locale",
        QCoreApplication::applicationDirPath() + "/../share/" + QApplication::applicationName() + "/locale",
        "/usr/share/" + QApplication::applicationName() + "/locale",
        "/usr/local/share/" + QApplication::applicationName() + "/locale"
    };

    for (const QString &path : searchPaths) {
        if (appTran.load(translationName, path)) {
            QApplication::installTranslator(&appTran);
            break;
        }
    }

    QCommandLineParser parser;
    parser.setApplicationDescription(
        QObject::tr("GUI for xdelta3 application.", "short description for --help and desktop file") + " "
        + QObject::tr("App for generating a binary difference "
                      "between two files in the form of delta encoding",
                      "extra description for --help"));
    parser.addHelpOption();
    parser.addVersionOption();
    parser.addPositionalArgument(QObject::tr("file"), QObject::tr("Name of the delta file"), QObject::tr("[file]"));
    parser.process(*app);

    // Check for xdelta3 binary
    if (QStandardPaths::findExecutable("xdelta3").isEmpty()) {
        QMessageBox::critical(nullptr, QObject::tr("Error"),
                              QObject::tr("xdelta3 binary not found. Please install xdelta3 package."));
        return EXIT_FAILURE;
    }
    QApplication::setApplicationDisplayName("xdelta3 GUI");
    QApplication::setWindowIcon(QIcon::fromTheme(QApplication::applicationName()));

    if (getuid() != 0) {
        const auto patchFile = parser.positionalArguments().isEmpty() ? "" : parser.positionalArguments().constFirst();
        MainWindow w(patchFile);
        w.show();
        return QApplication::exec();
    } else {
        QApplication::beep();
        QMessageBox::critical(
            nullptr, QString(),
            QObject::tr("You must run this program as normal user.", "warning about running application as root"));
        return EXIT_FAILURE;
    }
}
