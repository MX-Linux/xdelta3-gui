<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="pl">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="27"/>
        <location filename="../mainwindow.ui" line="39"/>
        <source>Create delta</source>
        <extracomment>meaning to create a delta file that bridges between the source and target file
----------
start process</extracomment>
        <translation>Utwórz deltę</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="30"/>
        <source>Create a binary difference between two files</source>
        <extracomment>meaning to create a delta file that bridges between the source and target file</extracomment>
        <translation>Utwórz różnicę binarną między dwoma plikami</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="49"/>
        <source>Options</source>
        <extracomment>program options</extracomment>
        <translation>Opcje</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="59"/>
        <source>None</source>
        <translation>Żaden</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="95"/>
        <source>Higher number = better compression ratio, but takes more time to finish</source>
        <translation>Wyższa liczba = lepszy współczynnik kompresji, ale ukończenie zajmuje więcej czasu</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="98"/>
        <source>Compression level</source>
        <extracomment>level of compression the delta file will use</extracomment>
        <translation>Poziom kompresji</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="118"/>
        <source>More compression using various compression algorithms</source>
        <translation>Więcej kompresji przy użyciu różnych algorytmów kompresji</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="121"/>
        <source>Secondary compression</source>
        <extracomment>an extra layer of compression</extracomment>
        <translation>Kompresja wtórna</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="131"/>
        <location filename="../mainwindow.ui" line="241"/>
        <source>File selection</source>
        <extracomment>area for selecting input and output files</extracomment>
        <translation>Wybór pliku</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="143"/>
        <source>select target (new) file</source>
        <extracomment>select the new file from which to create a delta between it and the source.</extracomment>
        <translation>wybierz plik docelowy (nowy)</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="160"/>
        <source>Target file</source>
        <translation>Plik docelowy</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="167"/>
        <source>Source file</source>
        <translation>Plik źródłowy</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="174"/>
        <source>Delta file name</source>
        <translation>Nazwa pliku delta</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="181"/>
        <source>Select source file...</source>
        <extracomment>starts a file chooser to select a file</extracomment>
        <translation>Wybierz plik źródłowy...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="194"/>
        <source>select source (old) file</source>
        <extracomment>select the original or source file</extracomment>
        <translation>wybierz plik źródłowy (stary)</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="201"/>
        <source>Select target file...</source>
        <extracomment>starts a file chooser to select a file</extracomment>
        <translation>Wybierz plik docelowy...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="208"/>
        <location filename="../mainwindow.ui" line="306"/>
        <source>Change location...</source>
        <extracomment>starts a file chooser to select destination for output delta file
----------
starts a file chooser to select destination for output file</extracomment>
        <translation>Zmień lokalizację...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="232"/>
        <location filename="../mainwindow.ui" line="332"/>
        <source>Apply delta</source>
        <extracomment>meaning to apply a delta file to a input file to create a new output file
----------
start the process</extracomment>
        <translation>Zastosuj deltę</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="235"/>
        <source>Create a new file applying a delta (difference) file to an original file</source>
        <extracomment>meaning to apply a delta file to a input file to create a new output file</extracomment>
        <translation>Utwórz nowy plik, stosując plik delta (różnicowy) do pliku oryginalnego</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="247"/>
        <source>Input file</source>
        <extracomment>a file to start with as the source or input</extracomment>
        <translation>Plik wejściowy</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="254"/>
        <source>select input file</source>
        <extracomment>select the input or older file</extracomment>
        <translation>wybierz plik wejściowy</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="261"/>
        <source>Select input file...</source>
        <extracomment>starts a file chooser to select a file</extracomment>
        <translation>Wybierz plik wejściowy...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="268"/>
        <source>Delta file</source>
        <extracomment>the delta or diff file between the input and the output</extracomment>
        <translation>Plik delta</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="275"/>
        <source>select delta</source>
        <extracomment>select the delta or patch file</extracomment>
        <translation>wybierz deltę</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="282"/>
        <source>Select delta...</source>
        <extracomment>starts a file chooser to select a file</extracomment>
        <translation>Wybierz deltę...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="289"/>
        <source>Output file</source>
        <extracomment>the final patched output file</extracomment>
        <translation>Plik wyjściowy</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="299"/>
        <source>use default, or set up a custom name</source>
        <extracomment>create the new file name</extracomment>
        <translation>użyj domyślnej nazwy lub ustaw własną</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="340"/>
        <source>Progress</source>
        <translation>Postęp</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="402"/>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="593"/>
        <source>ISO Files (*.iso);;All Files (*)</source>
        <comment>kinds of files to choose</comment>
        <translation>Pliki ISO (*.iso);;Wszystkie pliki (*)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="311"/>
        <source>Select file</source>
        <comment>choose a file</comment>
        <translation>Wybierz plik</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="223"/>
        <source>Could not move the temporary file to &apos;%1&apos;.</source>
        <translation>Nie można przenieść pliku tymczasowego do &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="237"/>
        <source>File was successfully written to &apos;%1&apos; directory.</source>
        <comment>information that file was successfully written</comment>
        <translation>Plik został pomyślnie zapisany w katalogu &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="243"/>
        <location filename="../mainwindow.cpp" line="267"/>
        <source>Cancelled</source>
        <translation>Anulowano</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="243"/>
        <location filename="../mainwindow.cpp" line="267"/>
        <source>Operation was cancelled.</source>
        <translation>Operacja została anulowana.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="245"/>
        <location filename="../mainwindow.cpp" line="269"/>
        <location filename="../mainwindow.cpp" line="378"/>
        <location filename="../mainwindow.cpp" line="389"/>
        <location filename="../mainwindow.cpp" line="399"/>
        <location filename="../mainwindow.cpp" line="406"/>
        <location filename="../mainwindow.cpp" line="456"/>
        <location filename="../mainwindow.cpp" line="541"/>
        <location filename="../mainwindow.cpp" line="549"/>
        <location filename="../mainwindow.cpp" line="559"/>
        <location filename="../mainwindow.cpp" line="566"/>
        <source>Error</source>
        <translation>Błąd</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="260"/>
        <source>Success</source>
        <comment>information on file written successfully</comment>
        <translation>Sukces </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="261"/>
        <source>File &apos;%1&apos; was successfully written.</source>
        <comment>information on file written successfully</comment>
        <translation>Plik &apos;%1&apos; został pomyślnie zapisany.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="263"/>
        <source>Patch size: %1</source>
        <comment>size of the created patch file</comment>
        <translation>Rozmiar poprawki: %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="264"/>
        <source>Took %1 to create the patch.</source>
        <comment>elapsed time, leave %1 untranslated</comment>
        <translation>Utworzenie poprawki zajęło %1.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="270"/>
        <source>Error: Could not write the file.</source>
        <comment>information that file was not written successfully</comment>
        <translation>Błąd: nie można zapisać pliku.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="347"/>
        <source>All Files (*)</source>
        <comment>kinds of files to choose</comment>
        <translation>Wszystkie pliki (*)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="348"/>
        <source>Select where to save the delta file</source>
        <comment>dialog title</comment>
        <translation>Wybierz miejsce zapisania pliku delta</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="349"/>
        <source>Select where to save the patched file</source>
        <comment>dialog title</comment>
        <translation>Wybierz miejsce zapisania poprawionego pliku</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="378"/>
        <source>Please enter a name for the output file.</source>
        <translation>Podaj nazwę pliku wyjściowego.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="389"/>
        <source>Output file is not writable.</source>
        <translation>Plik wyjściowy nie jest zapisywalny.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="394"/>
        <source>File exists</source>
        <translation>Plik istnieje</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="856"/>
        <source>%1 output size</source>
        <comment>exact output file size from delta, leave %1 untranslated</comment>
        <translation>Rozmiar wyjściowy %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="862"/>
        <source>~%1 estimated size</source>
        <comment>estimated output file size, leave %1 untranslated</comment>
        <translation>Szacowany rozmiar ~%1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="399"/>
        <location filename="../mainwindow.cpp" line="559"/>
        <source>Output directory is not writable.</source>
        <translation>Katalog wyjściowy nie jest zapisywalny.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="407"/>
        <location filename="../mainwindow.cpp" line="567"/>
        <source>Could not create a temporary file in the destination directory.</source>
        <translation>Nie można utworzyć pliku tymczasowego w katalogu docelowym.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="473"/>
        <source>File &apos;%1&apos; not found or not a file, please double-check the input.</source>
        <comment>warning about file not found</comment>
        <translation>Plik &apos;%1&apos; nie został znaleziony lub nie jest plikiem, sprawdź dokładnie dane wejściowe.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="346"/>
        <location filename="../mainwindow.cpp" line="594"/>
        <source>Delta Files (*.xdelta3);;All Files (*)</source>
        <comment>kinds of files to choose</comment>
        <translation>Pliki delta (*.xdelta3);;Wszystkie pliki (*)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="542"/>
        <source>Source and target are the same file; the patch would be empty.</source>
        <translation>Plik źródłowy i docelowy to ten sam plik; poprawka będzie pusta.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="499"/>
        <source>Path exists but is a directory.</source>
        <translation>Ścieżka istnieje, ale jest katalogiem.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="395"/>
        <source>Output file exists, do you want to overwrite?</source>
        <comment>warning about overwriting an existing file</comment>
        <translation>Plik wyjściowy istnieje. Czy chcesz go nadpisać?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="501"/>
        <source>File is not writable.</source>
        <translation>Plik nie jest zapisywalny.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="505"/>
        <source>Parent directory does not exist.</source>
        <translation>Katalog nadrzędny nie istnieje.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="507"/>
        <source>Parent directory is not writable.</source>
        <translation>Katalog nadrzędny nie jest zapisywalny.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="509"/>
        <source>Filename cannot be empty.</source>
        <translation>Nazwa pliku nie może być pusta.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="514"/>
        <source>File does not exist.</source>
        <translation>Plik nie istnieje.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="516"/>
        <source>Path is a directory, not a file.</source>
        <translation>Ścieżka określa katalog, a nie plik.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="518"/>
        <source>File is not readable (check permissions).</source>
        <translation>Plik nie nadaje się do odczytu (sprawdź uprawnienia).</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="554"/>
        <source>File exists</source>
        <comment>warning about overwriting file</comment>
        <translation>Plik istnieje</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="555"/>
        <source>Delta file exists, do you want to overwrite?</source>
        <comment>warning about overwriting file</comment>
        <translation>Plik delta istnieje. Czy chcesz go nadpisać?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="801"/>
        <source>%1% (%2 / %3) %4/s</source>
        <translation>%1% (%2 / %3) %4/s</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="852"/>
        <source>~%1 remaining</source>
        <comment>estimated time remaining, leave %1 untranslated</comment>
        <translation>~%1 pozostało</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="871"/>
        <source>Writing file: %1</source>
        <translation>Zapis pliku: %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="872"/>
        <source>Creating file: %1</source>
        <translation>Tworzenie pliku: %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="236"/>
        <source>Success</source>
        <comment>information that file was successfully written</comment>
        <translation>Sukces </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="240"/>
        <source>Took %1 to patch the file.</source>
        <comment>elapsed time, leave %1 untranslated</comment>
        <translation>Wykonano %1 czynności w celu załatania pliku.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="246"/>
        <source>Error: Could not write the file.</source>
        <comment>information that there was an error creating the file</comment>
        <translation>Błąd: nie można zapisać pliku.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="457"/>
        <source>Please enter a name for the delta file.</source>
        <comment>name of delta file being created</comment>
        <translation>Podaj nazwę pliku delta.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="472"/>
        <source>File not found</source>
        <comment>warning about file not found</comment>
        <translation>Plik nie został znaleziony</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="479"/>
        <source>Permission denied</source>
        <translation>Odmowa uprawnienia</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="480"/>
        <source>File &apos;%1&apos; is not readable. Please check your permissions.</source>
        <translation>Plik „%1” nie nadaje się do odczytu. Sprawdź swoje uprawnienia.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="549"/>
        <source>Delta file is not writable.</source>
        <translation>Plik delta nie jest zapisywalny.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../main.cpp" line="58"/>
        <source>Error</source>
        <translation>Błąd</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="59"/>
        <source>xdelta3 binary not found. Please install xdelta3 package.</source>
        <translation>Nie znaleziono pliku binarnego xdelta3. Zainstaluj pakiet xdelta3.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="69"/>
        <source>GUI for xdelta3 application.</source>
        <comment>short description for --help and desktop file</comment>
        <translation>Interfejs graficzny dla programu xdelta3.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="70"/>
        <source>App for generating a binary difference between two files in the form of delta encoding</source>
        <comment>extra description for --help</comment>
        <translation>Program do generowania różnicy binarnej między dwoma plikami w formie kodowania delta</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="75"/>
        <source>file</source>
        <translation>plik</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="75"/>
        <source>Name of the delta file</source>
        <translation>Nazwa pliku delta</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="75"/>
        <source>[file]</source>
        <translation>[plik]</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="113"/>
        <source>You must run this program as normal user.</source>
        <comment>warning about running application as root</comment>
        <translation>Musisz uruchomić ten program jako zwykły użytkownik.</translation>
    </message>
</context>
</TS>