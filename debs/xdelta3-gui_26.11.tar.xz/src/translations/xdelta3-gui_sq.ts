<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="sq">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="27"/>
        <location filename="../mainwindow.ui" line="39"/>
        <source>Create delta</source>
        <extracomment>meaning to create a delta file that bridges between the source and target file
----------
start process</extracomment>
        <translation>Krijoje diferencën</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="30"/>
        <source>Create a binary difference between two files</source>
        <extracomment>meaning to create a delta file that bridges between the source and target file</extracomment>
        <translation>Krijoni një diferencë dyore mes dy kartelash</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="49"/>
        <source>Options</source>
        <extracomment>program options</extracomment>
        <translation>Mundësi</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="59"/>
        <source>None</source>
        <translation>Asnjë</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="95"/>
        <source>Higher number = better compression ratio, but takes more time to finish</source>
        <translation>Më i madh numri = më e mirë shkalla e ngjeshjes, por do më tepër kohë të përfundojë</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="98"/>
        <source>Compression level</source>
        <extracomment>level of compression the delta file will use</extracomment>
        <translation>Shkallë ngjeshjeje</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="118"/>
        <source>More compression using various compression algorithms</source>
        <translation>Më tepër ngjeshje, duke përdorur algoritme të ndryshëm ngjeshjeje</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="121"/>
        <source>Secondary compression</source>
        <extracomment>an extra layer of compression</extracomment>
        <translation>Ngjeshje dytësore</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="131"/>
        <location filename="../mainwindow.ui" line="241"/>
        <source>File selection</source>
        <extracomment>area for selecting input and output files</extracomment>
        <translation>Përzgjedhje kartele</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="143"/>
        <source>select target (new) file</source>
        <extracomment>select the new file from which to create a delta between it and the source.</extracomment>
        <translation>përzgjidhni kartelë objektiv (të re)</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="160"/>
        <source>Target file</source>
        <translation>Kartelë e synuar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="167"/>
        <source>Source file</source>
        <translation>Kartelë burim</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="174"/>
        <source>Delta file name</source>
        <translation>Emër kartele Delta</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="181"/>
        <source>Select source file...</source>
        <extracomment>starts a file chooser to select a file</extracomment>
        <translation>Përzgjidhni kartelë burim…</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="194"/>
        <source>select source (old) file</source>
        <extracomment>select the original or source file</extracomment>
        <translation>përzgjidhni kartelë burim (të vjetër)</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="201"/>
        <source>Select target file...</source>
        <extracomment>starts a file chooser to select a file</extracomment>
        <translation>Përzgjidhni kartelë synim…</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="208"/>
        <location filename="../mainwindow.ui" line="306"/>
        <source>Change location...</source>
        <extracomment>starts a file chooser to select destination for output delta file
----------
starts a file chooser to select destination for output file</extracomment>
        <translation>Ndryshoni vendndodhje…</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="232"/>
        <location filename="../mainwindow.ui" line="332"/>
        <source>Apply delta</source>
        <extracomment>meaning to apply a delta file to a input file to create a new output file
----------
start the process</extracomment>
        <translation>Aplikoje deltan</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="235"/>
        <source>Create a new file applying a delta (difference) file to an original file</source>
        <extracomment>meaning to apply a delta file to a input file to create a new output file</extracomment>
        <translation>Krijoni një kartelë të re duke aplikuar një kartelë delta (diferencë) ndaj një kartele origjinale</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="247"/>
        <source>Input file</source>
        <extracomment>a file to start with as the source or input</extracomment>
        <translation>Kartelë për t’u dhënë</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="254"/>
        <source>select input file</source>
        <extracomment>select the input or older file</extracomment>
        <translation>përzgjidhni kartelën që jepet</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="261"/>
        <source>Select input file...</source>
        <extracomment>starts a file chooser to select a file</extracomment>
        <translation>Përzgjidhni kartelën që jepet…</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="268"/>
        <source>Delta file</source>
        <extracomment>the delta or diff file between the input and the output</extracomment>
        <translation>Kartelë delta</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="275"/>
        <source>select delta</source>
        <extracomment>select the delta or patch file</extracomment>
        <translation>përzgjidhni delta</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="282"/>
        <source>Select delta...</source>
        <extracomment>starts a file chooser to select a file</extracomment>
        <translation>Përzgjidhni delta…</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="289"/>
        <source>Output file</source>
        <extracomment>the final patched output file</extracomment>
        <translation>Kartelë përfundim</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="299"/>
        <source>use default, or set up a custom name</source>
        <extracomment>create the new file name</extracomment>
        <translation>përdorni parazgjedhjen, ose ujdisni një emër vetjak</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="340"/>
        <source>Progress</source>
        <translation>Ecuri</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="402"/>
        <source>Cancel</source>
        <translation>Anuloje</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="593"/>
        <source>ISO Files (*.iso);;All Files (*)</source>
        <comment>kinds of files to choose</comment>
        <translation>Kartela ISO (*.iso);;Krejt Kartelat (*)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="311"/>
        <source>Select file</source>
        <comment>choose a file</comment>
        <translation>Përzgjidhni kartelë</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="223"/>
        <source>Could not move the temporary file to &apos;%1&apos;.</source>
        <translation>S’u shpu dot te “%1” kartela e përkohshme.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="237"/>
        <source>File was successfully written to &apos;%1&apos; directory.</source>
        <comment>information that file was successfully written</comment>
        <translation>Kartela u shkrua me sukses te drejtoria “%1“.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="243"/>
        <location filename="../mainwindow.cpp" line="267"/>
        <source>Cancelled</source>
        <translation>U anulua</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="243"/>
        <location filename="../mainwindow.cpp" line="267"/>
        <source>Operation was cancelled.</source>
        <translation>Veprimi u anulua.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="245"/>
        <location filename="../mainwindow.cpp" line="269"/>
        <location filename="../mainwindow.cpp" line="378"/>
        <location filename="../mainwindow.cpp" line="389"/>
        <location filename="../mainwindow.cpp" line="399"/>
        <location filename="../mainwindow.cpp" line="406"/>
        <location filename="../mainwindow.cpp" line="456"/>
        <location filename="../mainwindow.cpp" line="541"/>
        <location filename="../mainwindow.cpp" line="549"/>
        <location filename="../mainwindow.cpp" line="559"/>
        <location filename="../mainwindow.cpp" line="566"/>
        <source>Error</source>
        <translation>Gabim</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="260"/>
        <source>Success</source>
        <comment>information on file written successfully</comment>
        <translation>Sukses</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="261"/>
        <source>File &apos;%1&apos; was successfully written.</source>
        <comment>information on file written successfully</comment>
        <translation>Kartela “%1” u shkrua me sukses.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="263"/>
        <source>Patch size: %1</source>
        <comment>size of the created patch file</comment>
        <translation>Madhësi arne: %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="264"/>
        <source>Took %1 to create the patch.</source>
        <comment>elapsed time, leave %1 untranslated</comment>
        <translation>U deshën %1 që të krijohej arna.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="270"/>
        <source>Error: Could not write the file.</source>
        <comment>information that file was not written successfully</comment>
        <translation>Gabim: S’u shkrua dot kartela.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="347"/>
        <source>All Files (*)</source>
        <comment>kinds of files to choose</comment>
        <translation>Krejt Kartelat (*)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="348"/>
        <source>Select where to save the delta file</source>
        <comment>dialog title</comment>
        <translation>Përzgjidhni ku të ruhet kartela delta</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="349"/>
        <source>Select where to save the patched file</source>
        <comment>dialog title</comment>
        <translation>Përzgjidhni ku të ruhet kartela e arnuar</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="378"/>
        <source>Please enter a name for the output file.</source>
        <translation>Ju lutemi, jepni një emër për kartelën përfundim.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="389"/>
        <source>Output file is not writable.</source>
        <translation>Kartela përfundim s’është e shkrueshme.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="394"/>
        <source>File exists</source>
        <translation>Kartela ekziston</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="856"/>
        <source>%1 output size</source>
        <comment>exact output file size from delta, leave %1 untranslated</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="862"/>
        <source>~%1 estimated size</source>
        <comment>estimated output file size, leave %1 untranslated</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="399"/>
        <location filename="../mainwindow.cpp" line="559"/>
        <source>Output directory is not writable.</source>
        <translation>Drejtoria përfundim s’është e shkrueshme.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="407"/>
        <location filename="../mainwindow.cpp" line="567"/>
        <source>Could not create a temporary file in the destination directory.</source>
        <translation>S’u krijua dot një kartelë e përkohshme te drejtoria vendmbërritje.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="473"/>
        <source>File &apos;%1&apos; not found or not a file, please double-check the input.</source>
        <comment>warning about file not found</comment>
        <translation>Kartela “%1” s’u gjet, ose s’është kartelë, ju lutemi, rikontrolloni ç’dhatë.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="346"/>
        <location filename="../mainwindow.cpp" line="594"/>
        <source>Delta Files (*.xdelta3);;All Files (*)</source>
        <comment>kinds of files to choose</comment>
        <translation>Kartela Delta (*.xdelta3);;Tërë Kartelat (*)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="542"/>
        <source>Source and target are the same file; the patch would be empty.</source>
        <translation>Burimi dhe objektivi janë e njëjta kartelë; arnimi do të ishte i zbrazët.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="499"/>
        <source>Path exists but is a directory.</source>
        <translation>Shtegu ekziston, por është një drejtori.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="395"/>
        <source>Output file exists, do you want to overwrite?</source>
        <comment>warning about overwriting an existing file</comment>
        <translation>Kartela përfundim ekziston, doni të mbishkruhet?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="501"/>
        <source>File is not writable.</source>
        <translation>Kartela s’është e shkrueshme.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="505"/>
        <source>Parent directory does not exist.</source>
        <translation>Drejtoria mëmë s’ekziston.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="507"/>
        <source>Parent directory is not writable.</source>
        <translation>Drejtoria mëmë s’është e shkrueshme.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="509"/>
        <source>Filename cannot be empty.</source>
        <translation>Emri i kartelës s’mund të jetë i zbrazët.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="514"/>
        <source>File does not exist.</source>
        <translation>Kartela s’ekziston.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="516"/>
        <source>Path is a directory, not a file.</source>
        <translation>Shtegu është një drejtori, jo një kartelë.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="518"/>
        <source>File is not readable (check permissions).</source>
        <translation>Kartela s’është e lexueshme (kontrolloni lejet).</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="554"/>
        <source>File exists</source>
        <comment>warning about overwriting file</comment>
        <translation>Kartela ekziston</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="555"/>
        <source>Delta file exists, do you want to overwrite?</source>
        <comment>warning about overwriting file</comment>
        <translation>Kartela delta ekziston, doni që të mbishkruhet?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="801"/>
        <source>%1% (%2 / %3) %4/s</source>
        <translation>%1% (%2 / %3) %4/s</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="852"/>
        <source>~%1 remaining</source>
        <comment>estimated time remaining, leave %1 untranslated</comment>
        <translation>Edhe ~%1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="871"/>
        <source>Writing file: %1</source>
        <translation>Po shkruhet kartelë: %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="872"/>
        <source>Creating file: %1</source>
        <translation>Po krijohet kartelë: %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="236"/>
        <source>Success</source>
        <comment>information that file was successfully written</comment>
        <translation>Sukses</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="240"/>
        <source>Took %1 to patch the file.</source>
        <comment>elapsed time, leave %1 untranslated</comment>
        <translation>U deshën %1 që të arnohej kartela.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="246"/>
        <source>Error: Could not write the file.</source>
        <comment>information that there was an error creating the file</comment>
        <translation>Gabim: S’u shkrua dot kartela.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="457"/>
        <source>Please enter a name for the delta file.</source>
        <comment>name of delta file being created</comment>
        <translation>Ju lutemi, jepni një emër për kartelën delta.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="472"/>
        <source>File not found</source>
        <comment>warning about file not found</comment>
        <translation>Kartela s’u gjet</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="479"/>
        <source>Permission denied</source>
        <translation>S’u dha leje</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="480"/>
        <source>File &apos;%1&apos; is not readable. Please check your permissions.</source>
        <translation>Kartela “%1” s’është e lexueshme. Ju lutemi, kontrolloni lejet tuaja.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="549"/>
        <source>Delta file is not writable.</source>
        <translation>Kartela delta s’është e shkrueshme.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../main.cpp" line="58"/>
        <source>Error</source>
        <translation>Gabim</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="59"/>
        <source>xdelta3 binary not found. Please install xdelta3 package.</source>
        <translation>S’u gjet dyori xdelta3. Ju lutemi, instaloni paketën xdelta3.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="69"/>
        <source>GUI for xdelta3 application.</source>
        <comment>short description for --help and desktop file</comment>
        <translation>GUI për aplikacionin xdelta3.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="70"/>
        <source>App for generating a binary difference between two files in the form of delta encoding</source>
        <comment>extra description for --help</comment>
        <translation>Aplikacion për prodhimin e një diference dyore mes dy kartelash në trajtën e kodimit delta</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="75"/>
        <source>file</source>
        <translation>kartelë</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="75"/>
        <source>Name of the delta file</source>
        <translation>Emër i kartelës delta</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="75"/>
        <source>[file]</source>
        <translation>[kartelë]</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="113"/>
        <source>You must run this program as normal user.</source>
        <comment>warning about running application as root</comment>
        <translation>Këtë program duhet ta xhironi si përdorues i thjeshtë.</translation>
    </message>
</context>
</TS>