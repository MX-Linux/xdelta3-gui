<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="ca">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="27"/>
        <location filename="../mainwindow.ui" line="39"/>
        <source>Create delta</source>
        <extracomment>meaning to create a delta file that bridges between the source and target file
----------
start process</extracomment>
        <translation>Crea delta</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="30"/>
        <source>Create a binary difference between two files</source>
        <extracomment>meaning to create a delta file that bridges between the source and target file</extracomment>
        <translation>Crea una diferència binària entre dos fitxers</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="49"/>
        <source>Options</source>
        <extracomment>program options</extracomment>
        <translation>Opcions </translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="59"/>
        <source>None</source>
        <translation>Cap</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="95"/>
        <source>Higher number = better compression ratio, but takes more time to finish</source>
        <translation>Número més alt = millor relació de compressió, però necessita més temps</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="98"/>
        <source>Compression level</source>
        <extracomment>level of compression the delta file will use</extracomment>
        <translation>Nivell de compressió</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="118"/>
        <source>More compression using various compression algorithms</source>
        <translation>Més compressió usant diversos algoritmes de compressió</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="121"/>
        <source>Secondary compression</source>
        <extracomment>an extra layer of compression</extracomment>
        <translation>Compressió secundària</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="131"/>
        <location filename="../mainwindow.ui" line="241"/>
        <source>File selection</source>
        <extracomment>area for selecting input and output files</extracomment>
        <translation>Selecció de fitxer</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="143"/>
        <source>select target (new) file</source>
        <extracomment>select the new file from which to create a delta between it and the source.</extracomment>
        <translation>selecciona fitxer objectiu (nou)</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="160"/>
        <source>Target file</source>
        <translation>Fitxer objectiu</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="167"/>
        <source>Source file</source>
        <translation>Fitxer origen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="174"/>
        <source>Delta file name</source>
        <translation>Nom del fitxer delta</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="181"/>
        <source>Select source file...</source>
        <extracomment>starts a file chooser to select a file</extracomment>
        <translation>Trieu el fitxer d&apos;origen...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="194"/>
        <source>select source (old) file</source>
        <extracomment>select the original or source file</extracomment>
        <translation>trieu el fitxer d&apos;origen (antic)</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="201"/>
        <source>Select target file...</source>
        <extracomment>starts a file chooser to select a file</extracomment>
        <translation>Trieu el fitxer objectiu</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="208"/>
        <location filename="../mainwindow.ui" line="306"/>
        <source>Change location...</source>
        <extracomment>starts a file chooser to select destination for output delta file
----------
starts a file chooser to select destination for output file</extracomment>
        <translation>Canvia ubicació...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="232"/>
        <location filename="../mainwindow.ui" line="332"/>
        <source>Apply delta</source>
        <extracomment>meaning to apply a delta file to a input file to create a new output file
----------
start the process</extracomment>
        <translation>Aplica la delta</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="235"/>
        <source>Create a new file applying a delta (difference) file to an original file</source>
        <extracomment>meaning to apply a delta file to a input file to create a new output file</extracomment>
        <translation>Crea un nou fitxer aplicant la delta (diferència) al fitxer original</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="247"/>
        <source>Input file</source>
        <extracomment>a file to start with as the source or input</extracomment>
        <translation>Fitxer d&apos;entrada</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="254"/>
        <source>select input file</source>
        <extracomment>select the input or older file</extracomment>
        <translation>trieu el fitxer d&apos;entrada</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="261"/>
        <source>Select input file...</source>
        <extracomment>starts a file chooser to select a file</extracomment>
        <translation>Trieu el fitxer d&apos;entrada...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="268"/>
        <source>Delta file</source>
        <extracomment>the delta or diff file between the input and the output</extracomment>
        <translation>Fitxer delta</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="275"/>
        <source>select delta</source>
        <extracomment>select the delta or patch file</extracomment>
        <translation>trieu la delta</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="282"/>
        <source>Select delta...</source>
        <extracomment>starts a file chooser to select a file</extracomment>
        <translation>Triant delta...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="289"/>
        <source>Output file</source>
        <extracomment>the final patched output file</extracomment>
        <translation>Fitxer de sortida</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="299"/>
        <source>use default, or set up a custom name</source>
        <extracomment>create the new file name</extracomment>
        <translation>usa el valor per omissió, o defineix un nom personalitzat</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="340"/>
        <source>Progress</source>
        <translation>Progrés </translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="402"/>
        <source>Cancel</source>
        <translation>Cancel·la</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="593"/>
        <source>ISO Files (*.iso);;All Files (*)</source>
        <comment>kinds of files to choose</comment>
        <translation>Fitxers ISO (*.iso);; Tots els fitxers (*)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="311"/>
        <source>Select file</source>
        <comment>choose a file</comment>
        <translation>Trieu el fitxer</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="223"/>
        <source>Could not move the temporary file to &apos;%1&apos;.</source>
        <translation>No he pogut moure el fitxer temporal a &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="237"/>
        <source>File was successfully written to &apos;%1&apos; directory.</source>
        <comment>information that file was successfully written</comment>
        <translation>El fitxer s&apos;ha escrit amb èxit al directori &apos;%1&apos; .</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="243"/>
        <location filename="../mainwindow.cpp" line="267"/>
        <source>Cancelled</source>
        <translation>Cancel·lat</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="243"/>
        <location filename="../mainwindow.cpp" line="267"/>
        <source>Operation was cancelled.</source>
        <translation>S&apos;ha cancel·lat l&apos;operació.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="245"/>
        <location filename="../mainwindow.cpp" line="269"/>
        <location filename="../mainwindow.cpp" line="378"/>
        <location filename="../mainwindow.cpp" line="389"/>
        <location filename="../mainwindow.cpp" line="399"/>
        <location filename="../mainwindow.cpp" line="406"/>
        <location filename="../mainwindow.cpp" line="456"/>
        <location filename="../mainwindow.cpp" line="541"/>
        <location filename="../mainwindow.cpp" line="549"/>
        <location filename="../mainwindow.cpp" line="559"/>
        <location filename="../mainwindow.cpp" line="566"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="260"/>
        <source>Success</source>
        <comment>information on file written successfully</comment>
        <translation>Correcte</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="261"/>
        <source>File &apos;%1&apos; was successfully written.</source>
        <comment>information on file written successfully</comment>
        <translation>El fitxer &apos;%1&apos; s&apos;ha escrit amb èxit.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="263"/>
        <source>Patch size: %1</source>
        <comment>size of the created patch file</comment>
        <translation>Mida del pedaç: %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="264"/>
        <source>Took %1 to create the patch.</source>
        <comment>elapsed time, leave %1 untranslated</comment>
        <translation>Agafeu %1 per crear el pedaç.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="270"/>
        <source>Error: Could not write the file.</source>
        <comment>information that file was not written successfully</comment>
        <translation>Error: no puc desar el fitxer.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="347"/>
        <source>All Files (*)</source>
        <comment>kinds of files to choose</comment>
        <translation>Tots els fitxers (*)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="348"/>
        <source>Select where to save the delta file</source>
        <comment>dialog title</comment>
        <translation>Trieu on desar el fitxer delta</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="349"/>
        <source>Select where to save the patched file</source>
        <comment>dialog title</comment>
        <translation>Trieu on desar el fitxer apedaçat</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="378"/>
        <source>Please enter a name for the output file.</source>
        <translation>Si us plau, entreu un nom per al fitxer de sortida.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="389"/>
        <source>Output file is not writable.</source>
        <translation>No es pot escriure al fitxer de sortida.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="394"/>
        <source>File exists</source>
        <translation>Aquest fitxer ja hi és</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="856"/>
        <source>%1 output size</source>
        <comment>exact output file size from delta, leave %1 untranslated</comment>
        <translation>%1 mida de sortida</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="862"/>
        <source>~%1 estimated size</source>
        <comment>estimated output file size, leave %1 untranslated</comment>
        <translation>~%1 mida estimada</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="399"/>
        <location filename="../mainwindow.cpp" line="559"/>
        <source>Output directory is not writable.</source>
        <translation>No es pot escriure al directori de sortida.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="407"/>
        <location filename="../mainwindow.cpp" line="567"/>
        <source>Could not create a temporary file in the destination directory.</source>
        <translation>No he pogut crear un fitxer temporal al directori destinació.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="473"/>
        <source>File &apos;%1&apos; not found or not a file, please double-check the input.</source>
        <comment>warning about file not found</comment>
        <translation>El fitxer &apos;%1&apos; no s&apos;ha trobat o no és un fitxer, si us plau comproveu l&apos;entrada.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="346"/>
        <location filename="../mainwindow.cpp" line="594"/>
        <source>Delta Files (*.xdelta3);;All Files (*)</source>
        <comment>kinds of files to choose</comment>
        <translation>Fitxers Delta (*.xdelta3);;Tots els fitxers (*)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="542"/>
        <source>Source and target are the same file; the patch would be empty.</source>
        <translation>Font i objectiu son el mateix fitxer; el pedaç seria buit.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="499"/>
        <source>Path exists but is a directory.</source>
        <translation>El camí ja hi és, però és un directori.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="395"/>
        <source>Output file exists, do you want to overwrite?</source>
        <comment>warning about overwriting an existing file</comment>
        <translation>Aquest fitxer ja hi és, el voleu sobreescriure?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="501"/>
        <source>File is not writable.</source>
        <translation>No es pot escriure al fitxer.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="505"/>
        <source>Parent directory does not exist.</source>
        <translation>El directori pare no existeix.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="507"/>
        <source>Parent directory is not writable.</source>
        <translation>No es pot escriure al directori pare.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="509"/>
        <source>Filename cannot be empty.</source>
        <translation>El nom de fitxer no pot estar buit.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="514"/>
        <source>File does not exist.</source>
        <translation>El fitxer no existeix.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="516"/>
        <source>Path is a directory, not a file.</source>
        <translation>El camí és un directori, no un fitxer,</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="518"/>
        <source>File is not readable (check permissions).</source>
        <translation>No es pot llegir el fitxer (comproveu permisos).</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="554"/>
        <source>File exists</source>
        <comment>warning about overwriting file</comment>
        <translation>Aquest fitxer ja hi és</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="555"/>
        <source>Delta file exists, do you want to overwrite?</source>
        <comment>warning about overwriting file</comment>
        <translation>El fitxer delta ja hi és, el voleu sobreescriure?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="801"/>
        <source>%1% (%2 / %3) %4/s</source>
        <translation>%1% (%2 / %3) %4/s</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="852"/>
        <source>~%1 remaining</source>
        <comment>estimated time remaining, leave %1 untranslated</comment>
        <translation>en queden ~%1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="871"/>
        <source>Writing file: %1</source>
        <translation>Escrivint el fitxer: %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="872"/>
        <source>Creating file: %1</source>
        <translation>Creant el fitxer: %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="236"/>
        <source>Success</source>
        <comment>information that file was successfully written</comment>
        <translation>Èxit</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="240"/>
        <source>Took %1 to patch the file.</source>
        <comment>elapsed time, leave %1 untranslated</comment>
        <translation>Agafeu %1 per apedaçar el fitxer.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="246"/>
        <source>Error: Could not write the file.</source>
        <comment>information that there was an error creating the file</comment>
        <translation>Error: no puc desar el fitxer.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="457"/>
        <source>Please enter a name for the delta file.</source>
        <comment>name of delta file being created</comment>
        <translation>Si us plau, entreu un nom per al fitxer delta.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="472"/>
        <source>File not found</source>
        <comment>warning about file not found</comment>
        <translation>No trobo el fitxer</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="479"/>
        <source>Permission denied</source>
        <translation>Permís denegat</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="480"/>
        <source>File &apos;%1&apos; is not readable. Please check your permissions.</source>
        <translation>El fitxer &apos;%1&apos; no és llegible. Si us plau, comproveu els permisos.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="549"/>
        <source>Delta file is not writable.</source>
        <translation>No es pot escriure al fitxer delta.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../main.cpp" line="58"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="59"/>
        <source>xdelta3 binary not found. Please install xdelta3 package.</source>
        <translation>No he trobat el binari xdelta3. Si us plau, instal·leu el paquet xdelta3 .</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="69"/>
        <source>GUI for xdelta3 application.</source>
        <comment>short description for --help and desktop file</comment>
        <translation>Aplicació IGU per xdelta3.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="70"/>
        <source>App for generating a binary difference between two files in the form of delta encoding</source>
        <comment>extra description for --help</comment>
        <translation>Aplicació per crear una diferència binària entre dos fitxers en forma de codificació delta</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="75"/>
        <source>file</source>
        <translation>fitxer</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="75"/>
        <source>Name of the delta file</source>
        <translation>Nom del fitxer delta</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="75"/>
        <source>[file]</source>
        <translation>[fitxer]</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="113"/>
        <source>You must run this program as normal user.</source>
        <comment>warning about running application as root</comment>
        <translation>Cal executar aquest programa com a usuari normal.</translation>
    </message>
</context>
</TS>