<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="sv">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="27"/>
        <location filename="../mainwindow.ui" line="39"/>
        <source>Create delta</source>
        <extracomment>meaning to create a delta file that bridges between the source and target file
----------
start process</extracomment>
        <translation>Skapa delta</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="30"/>
        <source>Create a binary difference between two files</source>
        <extracomment>meaning to create a delta file that bridges between the source and target file</extracomment>
        <translation>Skapa en binär skillnad mellan två filer</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="49"/>
        <source>Options</source>
        <extracomment>program options</extracomment>
        <translation>Alternativ</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="59"/>
        <source>None</source>
        <translation>Ingen</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="95"/>
        <source>Higher number = better compression ratio, but takes more time to finish</source>
        <translation>Högre nummerr = bättre kompressionsgrad, men tar längre tid att slutföra</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="98"/>
        <source>Compression level</source>
        <extracomment>level of compression the delta file will use</extracomment>
        <translation>Kompressionsnivå</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="118"/>
        <source>More compression using various compression algorithms</source>
        <translation>Mer kompression genom att använda olika kompressionsalgoritmer</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="121"/>
        <source>Secondary compression</source>
        <extracomment>an extra layer of compression</extracomment>
        <translation>Sekundär kompression</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="131"/>
        <location filename="../mainwindow.ui" line="241"/>
        <source>File selection</source>
        <extracomment>area for selecting input and output files</extracomment>
        <translation>Filval</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="143"/>
        <source>select target (new) file</source>
        <extracomment>select the new file from which to create a delta between it and the source.</extracomment>
        <translation>välj mål (ny) fil</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="160"/>
        <source>Target file</source>
        <translation>Målfil</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="167"/>
        <source>Source file</source>
        <translation>Källfil</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="174"/>
        <source>Delta file name</source>
        <translation>Deltafilsnamn</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="181"/>
        <source>Select source file...</source>
        <extracomment>starts a file chooser to select a file</extracomment>
        <translation>Välj källfil...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="194"/>
        <source>select source (old) file</source>
        <extracomment>select the original or source file</extracomment>
        <translation>välj käll (gammal) fil</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="201"/>
        <source>Select target file...</source>
        <extracomment>starts a file chooser to select a file</extracomment>
        <translation>Välj målfil...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="208"/>
        <location filename="../mainwindow.ui" line="306"/>
        <source>Change location...</source>
        <extracomment>starts a file chooser to select destination for output delta file
----------
starts a file chooser to select destination for output file</extracomment>
        <translation>Byt plats...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="232"/>
        <location filename="../mainwindow.ui" line="332"/>
        <source>Apply delta</source>
        <extracomment>meaning to apply a delta file to a input file to create a new output file
----------
start the process</extracomment>
        <translation>Tillämpa delta</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="235"/>
        <source>Create a new file applying a delta (difference) file to an original file</source>
        <extracomment>meaning to apply a delta file to a input file to create a new output file</extracomment>
        <translation>Skapa en ny fil genom att applicera en delta (skillnads) fil på en orginalfil.</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="247"/>
        <source>Input file</source>
        <extracomment>a file to start with as the source or input</extracomment>
        <translation>Input-fil</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="254"/>
        <source>select input file</source>
        <extracomment>select the input or older file</extracomment>
        <translation>välj input-fil</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="261"/>
        <source>Select input file...</source>
        <extracomment>starts a file chooser to select a file</extracomment>
        <translation>Välj inmatningsfil...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="268"/>
        <source>Delta file</source>
        <extracomment>the delta or diff file between the input and the output</extracomment>
        <translation>Deltafil</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="275"/>
        <source>select delta</source>
        <extracomment>select the delta or patch file</extracomment>
        <translation>välj delta</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="282"/>
        <source>Select delta...</source>
        <extracomment>starts a file chooser to select a file</extracomment>
        <translation>Välj delta...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="289"/>
        <source>Output file</source>
        <extracomment>the final patched output file</extracomment>
        <translation>Utdatafil</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="299"/>
        <source>use default, or set up a custom name</source>
        <extracomment>create the new file name</extracomment>
        <translation>använd standard, eller ställ in ett anpassat namn</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="340"/>
        <source>Progress</source>
        <translation>Framsteg</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="402"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="593"/>
        <source>ISO Files (*.iso);;All Files (*)</source>
        <comment>kinds of files to choose</comment>
        <translation>ISO Filer (*.iso);;Alla Filer (*)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="311"/>
        <source>Select file</source>
        <comment>choose a file</comment>
        <translation>Välj fil</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="223"/>
        <source>Could not move the temporary file to &apos;%1&apos;.</source>
        <translation>Kunde inte flytta den temporära filen till &apos;%1&apos;.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="237"/>
        <source>File was successfully written to &apos;%1&apos; directory.</source>
        <comment>information that file was successfully written</comment>
        <translation>Filen blev framgångsrikt skriven till &apos;%1&apos; katalogen.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="243"/>
        <location filename="../mainwindow.cpp" line="267"/>
        <source>Cancelled</source>
        <translation>Avbruten</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="243"/>
        <location filename="../mainwindow.cpp" line="267"/>
        <source>Operation was cancelled.</source>
        <translation>Operationen avbröts.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="245"/>
        <location filename="../mainwindow.cpp" line="269"/>
        <location filename="../mainwindow.cpp" line="378"/>
        <location filename="../mainwindow.cpp" line="389"/>
        <location filename="../mainwindow.cpp" line="399"/>
        <location filename="../mainwindow.cpp" line="406"/>
        <location filename="../mainwindow.cpp" line="456"/>
        <location filename="../mainwindow.cpp" line="541"/>
        <location filename="../mainwindow.cpp" line="549"/>
        <location filename="../mainwindow.cpp" line="559"/>
        <location filename="../mainwindow.cpp" line="566"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="260"/>
        <source>Success</source>
        <comment>information on file written successfully</comment>
        <translation>Det lyckades</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="261"/>
        <source>File &apos;%1&apos; was successfully written.</source>
        <comment>information on file written successfully</comment>
        <translation>Filen &apos;%1&apos; blev framgångsrikt skriven.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="263"/>
        <source>Patch size: %1</source>
        <comment>size of the created patch file</comment>
        <translation>Patch storlek: %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="264"/>
        <source>Took %1 to create the patch.</source>
        <comment>elapsed time, leave %1 untranslated</comment>
        <translation>Tog %1 för att skapa patchen.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="270"/>
        <source>Error: Could not write the file.</source>
        <comment>information that file was not written successfully</comment>
        <translation>Fel: Kunde inte skriva filen.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="347"/>
        <source>All Files (*)</source>
        <comment>kinds of files to choose</comment>
        <translation>Alla Filer (*)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="348"/>
        <source>Select where to save the delta file</source>
        <comment>dialog title</comment>
        <translation>Välj var du vill spara deltafilen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="349"/>
        <source>Select where to save the patched file</source>
        <comment>dialog title</comment>
        <translation>Välj var du vill spara den patchade filen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="378"/>
        <source>Please enter a name for the output file.</source>
        <translation>Vänligen ange ett namn för utdatafilen.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="389"/>
        <source>Output file is not writable.</source>
        <translation>Utdata filen är inte skrivbar.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="394"/>
        <source>File exists</source>
        <translation>Filen finns</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="856"/>
        <source>%1 output size</source>
        <comment>exact output file size from delta, leave %1 untranslated</comment>
        <translation>%1 utdata storlek</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="862"/>
        <source>~%1 estimated size</source>
        <comment>estimated output file size, leave %1 untranslated</comment>
        <translation>~%1 uppskattad storlek</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="399"/>
        <location filename="../mainwindow.cpp" line="559"/>
        <source>Output directory is not writable.</source>
        <translation>Utdata katalogen är inte skrivbar.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="407"/>
        <location filename="../mainwindow.cpp" line="567"/>
        <source>Could not create a temporary file in the destination directory.</source>
        <translation>Kunde inte skapa en temporär fil i målkatalogen.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="473"/>
        <source>File &apos;%1&apos; not found or not a file, please double-check the input.</source>
        <comment>warning about file not found</comment>
        <translation>Filen &apos;%1&apos; ej funnen eller inte en fil, var vänlig dubbelkolla indata.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="346"/>
        <location filename="../mainwindow.cpp" line="594"/>
        <source>Delta Files (*.xdelta3);;All Files (*)</source>
        <comment>kinds of files to choose</comment>
        <translation>Delta Filer (*.xdelta3);;All Files (*)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="542"/>
        <source>Source and target are the same file; the patch would be empty.</source>
        <translation>Källa och mål är samma fil; patchen skulle bli tom.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="499"/>
        <source>Path exists but is a directory.</source>
        <translation>Sökvägen finns men är en katalog.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="395"/>
        <source>Output file exists, do you want to overwrite?</source>
        <comment>warning about overwriting an existing file</comment>
        <translation>Utdatafilen finns redan, vill du skriva över den befintliga filen?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="501"/>
        <source>File is not writable.</source>
        <translation>Filen är inte skrivbar.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="505"/>
        <source>Parent directory does not exist.</source>
        <translation>Överordnad katalog finns inte.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="507"/>
        <source>Parent directory is not writable.</source>
        <translation>Överordnad katalog är inte skrivbar.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="509"/>
        <source>Filename cannot be empty.</source>
        <translation>Filnamn kan inte vara tomt.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="514"/>
        <source>File does not exist.</source>
        <translation>Filen finns inte.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="516"/>
        <source>Path is a directory, not a file.</source>
        <translation>Sökvägen är en katalog, inte en fil.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="518"/>
        <source>File is not readable (check permissions).</source>
        <translation>Filen är inte läsbar (kontrollera rättigheter).</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="554"/>
        <source>File exists</source>
        <comment>warning about overwriting file</comment>
        <translation>Filen finns</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="555"/>
        <source>Delta file exists, do you want to overwrite?</source>
        <comment>warning about overwriting file</comment>
        <translation>Deltafilen finns, vill du skriva över?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="801"/>
        <source>%1% (%2 / %3) %4/s</source>
        <translation>%1% (%2 / %3) %4/s</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="852"/>
        <source>~%1 remaining</source>
        <comment>estimated time remaining, leave %1 untranslated</comment>
        <translation>~%1 återstår</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="871"/>
        <source>Writing file: %1</source>
        <translation>Skriver fil: %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="872"/>
        <source>Creating file: %1</source>
        <translation>Skapar fil: %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="236"/>
        <source>Success</source>
        <comment>information that file was successfully written</comment>
        <translation>Det lyckades</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="240"/>
        <source>Took %1 to patch the file.</source>
        <comment>elapsed time, leave %1 untranslated</comment>
        <translation>Tog %1 att patcha filen.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="246"/>
        <source>Error: Could not write the file.</source>
        <comment>information that there was an error creating the file</comment>
        <translation>Fel: Kunde inte skriva filen.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="457"/>
        <source>Please enter a name for the delta file.</source>
        <comment>name of delta file being created</comment>
        <translation>Var vänlig skriv in ett namn för deltafilen.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="472"/>
        <source>File not found</source>
        <comment>warning about file not found</comment>
        <translation>Filen hittades inte</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="479"/>
        <source>Permission denied</source>
        <translation>Rättighet nekad</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="480"/>
        <source>File &apos;%1&apos; is not readable. Please check your permissions.</source>
        <translation>Filen &apos;%1&apos; är inte läsbar. Var vänlig kontrollera dina rättigheter.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="549"/>
        <source>Delta file is not writable.</source>
        <translation>Deltafilen är inte skrivbar.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../main.cpp" line="58"/>
        <source>Error</source>
        <translation>Fel</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="59"/>
        <source>xdelta3 binary not found. Please install xdelta3 package.</source>
        <translation>xdelta3 binär ej funnen. Var vänlig installera xdelta3 paketet.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="69"/>
        <source>GUI for xdelta3 application.</source>
        <comment>short description for --help and desktop file</comment>
        <translation>GUI för xdelta3 applikation.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="70"/>
        <source>App for generating a binary difference between two files in the form of delta encoding</source>
        <comment>extra description for --help</comment>
        <translation>App för att generera en binär skillnad mellan två filer i form av deltakodning</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="75"/>
        <source>file</source>
        <translation>fil</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="75"/>
        <source>Name of the delta file</source>
        <translation>Namn på deltafilen</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="75"/>
        <source>[file]</source>
        <translation>[fil]</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="113"/>
        <source>You must run this program as normal user.</source>
        <comment>warning about running application as root</comment>
        <translation>Du måste köra det här programmet som vanlig användare.</translation>
    </message>
</context>
</TS>